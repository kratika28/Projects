package com.bank.bean;

    import org.springframework.stereotype.Component;
	import org.springframework.stereotype.Service;

import net.java.dev.springannotation.annotation.Bean;

	@Service
	@Component
	@Bean
	public class BankEntitiy {

		private String Ifsc;
		private String Branch;
		private String Address;
		private String City;
		private String District;
		private String State;
		
		public BankEntitiy() {
			super();
		}
		
		public BankEntitiy(String ifsc, String branch, 
				String address, String district, 
				String city, String state) {
			super();
			Ifsc = ifsc;
			Branch = branch;
			Address = address;
			District = district;
			City = city;
			State = state;
		}
		public String getIfsc() {
			return Ifsc;
		}
		public void setIfsc(String ifsc) {
			Ifsc = ifsc;
		}
		public String getBranch() {
			return Branch;
		}
		public void setBranch(String branch) {
			Branch = branch;
		}
		public String getAddress() {
			return Address;
		}
		public void setAddress(String address) {
			Address = address;
		}
		public String getDistrict() {
			return District;
		}
		public void setDistrict(String district) {
			District = district;
		}
		public String getCity() {
			return City;
		}
		public void setCity(String city) {
			City = city;
		}
		public String getState() {
			return State;
		}
		public void setState(String state) {
			State = state;
		}
		
		
		
		
	}




