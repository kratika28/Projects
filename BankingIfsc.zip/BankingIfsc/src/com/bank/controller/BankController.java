package com.bank.controller;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.bank.bean.BankEntitiy;
import com.bank.dao.BankDetailsServiceDao;

import net.java.dev.springannotation.annotation.Bean;

@Controller
@Bean
@Component
public class BankController {
	
	@Autowired
	private BankDetailsServiceDao bankDetailsServiceDao;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String BankHome() {
		System.out.println("inside BankController class BankHome method");
		return "index.jsp";
	}
	
	@RequestMapping(value = "/bankList", method = RequestMethod.POST)
	public ModelAndView BankList(HttpServletRequest req, HttpServletResponse res) {
		System.out.println("inside BankController class BankHome method");
		String Ifsc = req.getParameter("ifsc");
	    List<BankEntitiy> bankList = bankDetailsServiceDao.getBankList();  
		ModelAndView mav =  new ModelAndView("bankList.jsp", "bankList", bankList);  
		return mav;
		
	}
}
