package com.bank.dao;

import java.util.List;

import org.springframework.stereotype.Service;

import com.bank.bean.BankEntitiy;

import net.java.dev.springannotation.annotation.Bean;

@Bean
@Service
public interface BankDetailsServiceDao {

	public BankEntitiy getBankDetails(String IFSC_CODE);
	
	public List<BankEntitiy> getBankList();
}
