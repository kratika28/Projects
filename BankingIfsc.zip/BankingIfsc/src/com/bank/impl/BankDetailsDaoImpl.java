package com.bank.impl;

import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.bank.dao.BankDetailsDao;
import com.bank.bean.BankEntitiy;
import com.bank.impl.BankRowMapper;

import net.java.dev.springannotation.annotation.Bean;
@Repository
@Bean
public class BankDetailsDaoImpl implements BankDetailsDao{

	@Autowired
	private DataSource dataSource;
	
	@Override
	public BankEntitiy getBankDetails(String IFSC_CODE) {
		
		List<BankEntitiy> bankList = new ArrayList<BankEntitiy>();
		
		String sql = "select * from bank where ifsc = " + IFSC_CODE;  
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
		bankList = jdbcTemplate.query(sql, new BankRowMapper());  
		return bankList.get(0);  
	}

	@Override
	public List<BankEntitiy> getBankList() {
		System.out.println("inside BankDetailsDaoImpl class getBankList method");
		  List<BankEntitiy> bankList = new ArrayList<BankEntitiy>();  
		  
		  String sql = "select * from bank";  
		  
		  JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);  
		  bankList = jdbcTemplate.query(sql, new BankRowMapper());  
		  return bankList;
	}

}
