package com.bank.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bank.dao.BankDetailsDao;

import net.java.dev.springannotation.annotation.Bean;

import com.bank.bean.BankEntitiy;

@Repository
@Bean
public class BankDetailsServiceDaoImpl implements BankDetailsDao{

	@Autowired
	private BankDetailsDao bankDetailsDao;
	
	@Override
	public BankEntitiy getBankDetails(String IFSC_CODE) {
		System.out.println("inside BankDetailsServiceDaoImpl class BankEntitiy getBankDetails method");
		return bankDetailsDao.getBankDetails(IFSC_CODE);
	}

	@Override
	public List<BankEntitiy> getBankList() {
		return bankDetailsDao.getBankList();
	}

}
