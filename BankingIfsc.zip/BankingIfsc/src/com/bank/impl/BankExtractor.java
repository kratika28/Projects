package com.bank.impl;


import java.sql.ResultSet;  
import java.sql.SQLException;  
import org.springframework.dao.DataAccessException;  
import org.springframework.jdbc.core.ResultSetExtractor;  
import com.bank.bean.BankEntitiy;  

public class BankExtractor implements ResultSetExtractor<BankEntitiy> {  

public BankEntitiy extractData(ResultSet resultSet) throws SQLException,  
 DataAccessException {  
	System.out.println("inside BankExtractor class extractData method");
	BankEntitiy bankEntitiy = new BankEntitiy();  
  
	bankEntitiy.setIfsc(resultSet.getString(0));  
	bankEntitiy.setBranch(resultSet.getString(1));
	bankEntitiy.setAddress(resultSet.getString(2));
	bankEntitiy.setDistrict(resultSet.getString(3));
	bankEntitiy.setCity(resultSet.getString(4));
	bankEntitiy.setState(resultSet.getString(5));
		  
	return bankEntitiy;  
}  

}  