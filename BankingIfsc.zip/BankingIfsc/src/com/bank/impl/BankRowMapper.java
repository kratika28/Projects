package com.bank.impl;

import java.sql.ResultSet;  
import java.sql.SQLException;  
import org.springframework.jdbc.core.RowMapper;

import com.bank.bean.BankEntitiy;  
  
public class BankRowMapper implements RowMapper<BankEntitiy> {  
  
 @Override  
 public BankEntitiy mapRow(ResultSet resultSet, int line) throws SQLException { 
	 System.out.println("inside BankRowMapper class BankEntitiy method");
	 BankExtractor bankExtractor = new BankExtractor();  
  return bankExtractor.extractData(resultSet);  
 }  
  
}  