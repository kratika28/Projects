package com.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.entity.BankEntity;
import com.services.BankServices;

@Controller
@RequestMapping(value = "kratika")
public class BankController {

	@Autowired
	BankServices bankServices;

	@RequestMapping(value = "/page", method = RequestMethod.GET)
	public ModelAndView getPage() {
		ModelAndView mav = new ModelAndView("homePage");
		return mav;
	}

	 @RequestMapping(value = "/getBankData", method = RequestMethod.POST)
	 public @ResponseBody void getData(HttpServletRequest req) {	 
		 HttpSession session = req.getSession();
		 session.setAttribute("ifsc_bank_code", req.getParameter("ifsc_code"));
	}
	 
	@RequestMapping(value = "/list", method = RequestMethod.POST)
	public @ResponseBody Map<String, Object> getAll(BankEntity bank) {
		Map<String, Object> map = new HashMap<String, Object>();

		// manual db:
		BankEntity be1 = new BankEntity();
		BankEntity be2 = new BankEntity();
		BankEntity be3 = new BankEntity();
		be1.setIfscCode("11");
		be2.setIfscCode("22");
		be3.setIfscCode("33");
		
		List<BankEntity> list = bankServices.list();

		if (list != null) {
			map.put("data", list.get(2));
		} else {
			map.put("status", "404");
			map.put("message", "Data not found");

		}

		return map;
	}
}
