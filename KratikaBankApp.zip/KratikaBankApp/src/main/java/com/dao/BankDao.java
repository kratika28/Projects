package com.dao;

import java.util.List;
import com.entity.BankEntity;

public interface BankDao {
	
	public List<BankEntity> list();	
}
