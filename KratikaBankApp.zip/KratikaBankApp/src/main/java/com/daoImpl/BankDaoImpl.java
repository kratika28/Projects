package com.daoImpl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.dao.BankDao;
import com.entity.BankEntity;

public class BankDaoImpl implements BankDao {

	@Autowired
	SessionFactory sessionFactory;
//	HttpServletRequest req;
	
	public List<BankEntity> list() {
		// TODO Auto-generated method stub	
		
		List<BankEntity> list = new ArrayList<BankEntity>();
		list = sessionFactory.getCurrentSession().createQuery("from Bank").list();
		//sessionFactory.getCurrentSession().load(BankEntity.class, Integer.parseInt((String) req.getAttribute("ifsc_bank_code")));
		return list;

	}
	
}
