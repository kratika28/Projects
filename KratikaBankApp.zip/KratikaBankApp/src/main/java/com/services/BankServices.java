package com.services;

import java.util.List;

import com.entity.BankEntity;

public interface BankServices {
	public List<BankEntity> list();
}
