package com.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.dao.BankDao;
import com.entity.BankEntity;
import com.services.BankServices;

public class BankServicesImpl implements BankServices{

	@Autowired
	BankDao bankDao;
	
	public List<BankEntity> list() {
		// TODO Auto-generated method stub
		return bankDao.list();
	}

}
