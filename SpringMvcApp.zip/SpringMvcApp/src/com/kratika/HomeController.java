package com.kratika;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;
import net.sf.json.JSONObject;

@Controller
public class HomeController {

	@Autowired
	StudentDAO studentDAO;

	ModelAndView mav = new ModelAndView();

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView getHomePage(HttpServletRequest req) {
		HttpSession session = req.getSession();
		if (session.getAttribute("LoginName") != null) {

			mav.setViewName("Welcome");
			mav.addObject("tabTitle", "Welcome");
			return mav;

		} else {

			mav.setViewName("home");
			mav.addObject("tabTitle", "Home");
			return mav;

		}
	}

	@RequestMapping(value = "/loginHere", method = RequestMethod.GET)
	public ModelAndView getLoginHerePage() {

		mav.setViewName("login");
		mav.addObject("tabTitle", "Login");
		return mav;

	}

	@RequestMapping(value = "/welcomeKratika", method = RequestMethod.GET)
	public ModelAndView getNewWelcome() {

		mav.setViewName("Welcome");
		mav.addObject("tabTitle", "Welcome");
		return mav;

	}

	@RequestMapping(value = "/RegisterHere", method = RequestMethod.GET)
	public ModelAndView getRegisterHerePage() {

		mav.setViewName("Register");
		mav.addObject("tabTitle", "Register");
		mav.addObject("msg", "Register Here..");
		return mav;
	}

	@RequestMapping(value = "/Register", method = RequestMethod.POST)
	public ModelAndView getRegister(@RequestParam("username") String userName, @RequestParam("Email") String Email,
			@RequestParam("Country") String Country, @RequestParam("Password") String Password,
			@RequestParam("Confirmpassword") String Confirmpassword) throws Exception {

		if (Password.equals(Confirmpassword)) {

			Student student = new Student();
			student.setName(userName);
			student.setEmail(Email);
			student.setCountry(Country);
			student.setPassword(Password);

			String url = "http://localhost:8085/SpringMvcApp/checkUserName/" + userName;
			
			RestTemplate restTemplate = new RestTemplate();
			
			Integer jsonObject = (Integer) restTemplate.getForObject(url, Integer.class);
			
			
			System.out.println("jsonObject " + jsonObject.toString());
			if(jsonObject > 0) {
				mav.setViewName("login");
				mav.addObject("tabTitle", "Login");
				mav.addObject("msg", "Username alraedy Exists..");
				return mav;
			}
			
			studentDAO.addStudent(student);

			mav.setViewName("login");
			mav.addObject("tabTitle", "Login");
			mav.addObject("msg", "Registration Successfull..You can Login now...");
			return mav;
		}
		ModelAndView mav = new ModelAndView();
		mav.setViewName("Error");
		mav.addObject("tabTitle", "Error Page");
		return mav;
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public ModelAndView getLogoutHere(HttpServletRequest req) {
		HttpSession session = req.getSession();
		session.invalidate();
		return new ModelAndView("redirect:/");
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView getWelcomePage(@RequestParam("userName") String userName,
			@RequestParam("password") String password, HttpServletRequest req) {
		// Student student = studentDAO.getStudent(userName, password);
		String url = "http://localhost:8085/SpringMvcApp/login1/" + userName + "/" + password;
		HttpSession session = req.getSession();
		RestTemplate restTemplate = new RestTemplate();
		JSONObject jsonObject = restTemplate.getForObject(url, JSONObject.class);
		if (jsonObject.getBoolean("isLogin")) {
			session.setAttribute("LoginName", jsonObject.getString("NAME"));
			session.setAttribute("Password", jsonObject.getString("PASSWORD"));
			session.setAttribute("Country", jsonObject.getString("COUNTRY"));
			session.setAttribute("Id", jsonObject.getInt("ID"));
			session.setAttribute("Email", jsonObject.getString("EMAIL"));
			
			
			return new ModelAndView("redirect:/welcomePage");
		} else {

			mav.setViewName("Error");
			mav.addObject("tabTitle", "Error Page");
			return mav;
		}
	}

	@RequestMapping(value = "/welcomePage", method = RequestMethod.GET)
	public ModelAndView getProperURL(HttpServletRequest req) {
		HttpSession session = req.getSession();
		List<Student> list = new ArrayList<Student>();
		list.add(new Student(session.getAttribute("Id"), session.getAttribute("LoginName"),
				session.getAttribute("Email"), session.getAttribute("Country")));

		mav.setViewName("Welcome");
		mav.addObject("tabTitle", "Welcome");
		mav.addObject("list", list);
		mav.addObject("date", new Date());
		return mav;
	}

	@RequestMapping(value = "/forgotpassword", method = RequestMethod.GET)
	public ModelAndView getforgotPassword() {

		mav.setViewName("forgot");
		mav.addObject("tabTitle", "Forgot Password");
		return mav;
	}

	@RequestMapping(value = "/Aboutus", method = RequestMethod.GET)
	public ModelAndView getAboutus() {

		mav.setViewName("content");
		mav.addObject("tabTitle", "About Us");
		mav.addObject("Mycontent", "About us");
		return mav;
	}

	@RequestMapping(value = "/Contactus", method = RequestMethod.GET)
	public ModelAndView getContactus() {

		mav.setViewName("contactus");
		mav.addObject("tabTitle", "Contact Us");
		mav.addObject("Mycontent", "Contact us");
		return mav;
	}

	@SuppressWarnings("unused")
	@RequestMapping(value = "/contactUsFillForm", method = RequestMethod.POST)
	public ModelAndView getContactUsFillForm(@RequestParam("message") String message) {
		String url = "http://localhost:8085/SpringMvcApp/contactUs1/" + message;
		RestTemplate restTemplate = new RestTemplate();
		JSONObject jsonObject = restTemplate.postForObject(url, "POST", JSONObject.class);
		return new ModelAndView("redirect:/data");
	}

	@RequestMapping(value = "/data", method = RequestMethod.GET)
	public ModelAndView getDataName() {

		mav.setViewName("content");
		mav.addObject("tabTitle", "Contact Us");
		mav.addObject("Mycontent", "Data Saved");
		return mav;
	}

	@RequestMapping(value = "/forgot", method = RequestMethod.POST)
	public ModelAndView recoverPass(@RequestParam("email") String email, @RequestParam("pass") String pass) {
		studentDAO.forgotPassword(pass, email);

		mav.setViewName("login");
		mav.addObject("tabTitle", "Login");
		mav.addObject("msg", "Password change successfully.. login now..");
		return mav;

	}

	@RequestMapping(value = "/editHere", method = RequestMethod.GET)
	public ModelAndView editHerePage(HttpServletRequest req) {

		HttpSession session = req.getSession();

		mav.setViewName("edit");
		mav.addObject("tabTitle", "Edit");
		mav.addObject("StudentId", session.getAttribute("Id"));
		mav.addObject("StudentName", session.getAttribute("LoginName"));
		mav.addObject("Email", session.getAttribute("Email"));
		mav.addObject("Country", session.getAttribute("Country"));

		return mav;
	}

	@SuppressWarnings("unused")
	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public ModelAndView editPage(@RequestParam("id") Integer id,
			                     @RequestParam("name") String name,
			                     @RequestParam("email") String email, 
			                     @RequestParam("country") String country) {
			
		String url = "http://localhost:8085/SpringMvcApp/edit1/" + id + "/" + name + "/" + email + "/" + country;
		System.out.println("" + url);
		RestTemplate restTemplate = new RestTemplate();
		JSONObject jsonObject = restTemplate.postForObject(url, "POST", JSONObject.class);
		mav.setViewName("redirect:/loginNow");

		return mav;

	}

	@RequestMapping(value = "/loginNow", method = RequestMethod.GET)
	public ModelAndView afterEditLoginURL() {

		mav.setViewName("login");
		mav.addObject("tabTitle", "login");
		mav.addObject("msg", "Edited successfully.. login now..");
		return mav;

	}

	/**
	 * @param req
	 * @return
	 */
	@SuppressWarnings("unused")
	@RequestMapping(value = "/deleteHere", method = RequestMethod.GET)
	public ModelAndView deleteHerePage(HttpServletRequest req) {

		HttpSession session = req.getSession();
		int id = (int) session.getAttribute("Id");
		
		String url = "http://localhost:8085/SpringMvcApp/delete1/" + id;
		System.out.println("" + url);
		RestTemplate restTemplate = new RestTemplate();
		JSONObject jsonObject = restTemplate.getForObject(url, JSONObject.class);
		
		mav.setViewName("Register");
		mav.addObject("tabTitle", "Register");
		mav.addObject("msg", "Deleted Successfully.. Register now..");
		return mav;
		
	}


	@RequestMapping(value = "/RegisterNow", method = RequestMethod.GET)
	public ModelAndView afterdeleteRegisterURL() {

		mav.setViewName("Register");
		mav.addObject("tabTitle", "Register");
		mav.addObject("msg", "Deleted Successfully.. Register now..");
		return mav;

	}

     @RequestMapping(value = "/studentListHere", method = RequestMethod.GET)
     public ModelAndView getStudentListPage() {
    
    	 List<Student> list = studentDAO.getAllStudents();
    	 
    	 mav.setViewName("studentlist");
    	 mav.addObject("list", list);
    	 mav.addObject("tabTitle", "StudentList");
         mav.addObject("msg", "List of Students");
         
         return mav;
    	 
     }

  }
