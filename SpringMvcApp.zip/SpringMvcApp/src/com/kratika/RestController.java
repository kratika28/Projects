package com.kratika;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import net.sf.json.JSONObject;

@org.springframework.web.bind.annotation.RestController
public class RestController {
	
	@SuppressWarnings("unused")
	private static final String student = null;
	@Autowired
	StudentDAO studentDao;

	@RequestMapping(value="/login1/{userName}/{password}", method=RequestMethod.GET)
	public ResponseEntity<JSONObject> getLoginJson(@PathVariable("userName") String userName,
			@PathVariable("password") String password){
		
		JSONObject jsonObject = studentDao.getStudent(userName, password);
		if (jsonObject == null) {
			return new ResponseEntity<JSONObject>(HttpStatus.NOT_FOUND);
		} else {
			return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.OK);
		}
	}
	
	@RequestMapping(value="/contactUs1/{message}", method=RequestMethod.POST)
	public ResponseEntity<JSONObject> getLoginJson(@PathVariable("message") String message){
		
		JSONObject jsonObject = studentDao.contactUsForm(message);
		if (jsonObject == null) {
			return new ResponseEntity<JSONObject>(HttpStatus.NOT_FOUND);
		} else {
			return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.OK);
		}
	}
	
	@RequestMapping(value="/edit1/{id}/{name}/{email}/{country}", method=RequestMethod.POST)
	public ResponseEntity<JSONObject> editStudent(@PathVariable("id") int id,
			                                      @PathVariable("name") String name,
			                                      @PathVariable("email") String email,
			                                      @PathVariable("country") String country) {
			                                      
		JSONObject jsonObject = studentDao.editStudent(id, name, email, country);
		if (jsonObject == null) {
			return new ResponseEntity<JSONObject>(HttpStatus.NOT_FOUND);
		} else {
			return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.OK);
		}
	}
	

	@RequestMapping(value="/delete1/{id}", method=RequestMethod.GET)
	public ResponseEntity<JSONObject> editStudent(@PathVariable("id") int id) {
			                                      
		JSONObject jsonObject = studentDao.deleteStudent(id);
		if (jsonObject == null) {
			return new ResponseEntity<JSONObject>(HttpStatus.NOT_FOUND);
		} else {
			return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.OK);
		}
	}
	

	}
