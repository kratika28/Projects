package com.kratika;

import java.util.List;

import net.sf.json.JSONObject;

public interface StudentDAO {

	public void addStudent(Student student);
	
    //public Student getStudent(String uname, String upass);
	
	public JSONObject getStudent(String uname, String upass);
	
	public void forgotPassword(String pass, String email);
	
	public JSONObject contactUsForm(String message);
	
	//public JSONObject editStudent(int id, String name, String email, String country);
	
	//public Student getStudentsById(int id);
	
	//public void editStudent(Student student);
	
	//public JSONObject  getAllStudents();
	
	public List<Student> getAllStudents();
	
	public JSONObject deleteStudent(int id);

	public JSONObject editStudent(int id, String name, String email, String country);

	public JSONObject checkUsernameExistance(String name) throws Exception;

	
	
	
	
	}


