package com.kratika;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import net.sf.json.JSONObject;

public class StudentDAOIMPL implements StudentDAO {

	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public void addStudent(Student student) {
		String sql = "insert into students values(?,?,?,?,?)";
		jdbcTemplate.update(sql, new Object[] { "1", student.getName(), student.getEmail(), student.getCountry(),
				student.getPassword() });
	}

	/*
	 * @Override public Student getStudent(String uname, String upass) { String sql
	 * = "select * from students where name=? and password=?";
	 * System.out.println(sql);
	 * 
	 * @SuppressWarnings("unchecked") Student student2 = (Student)
	 * jdbcTemplate.queryForObject(sql, new Object[] {uname, upass}, new RowMapper()
	 * { public Student mapRow(ResultSet rs, int rowNum) throws SQLException {
	 * Student student1 = new Student(); student1.setId(rs.getInt(1));
	 * student1.setName(rs.getString(2)); student1.setEmail(rs.getString(4));
	 * student1.setCountry(rs.getString(5));
	 * 
	 * return student1; } }); return student2; }
	 */

	@Override
	public void forgotPassword(String pass, String email) {
		Student student = getEmail(email);
		if (email.equals(student.getEmail())) {
			String sql = "update students set password ='" + pass + "' where email='" + email + "'";
			System.out.println(sql);
			jdbcTemplate.execute(sql);
		}
	}

	public Student getEmail(String email) {
		String sql = "select * from students where email=?";

		Student student2 = (Student) jdbcTemplate.queryForObject(sql, new Object[] { email }, new RowMapper<Student>() {
			public Student mapRow(ResultSet rs, int rowNum) throws SQLException {
				Student student1 = new Student();
				student1.setEmail(rs.getString(4));
				System.out.println("get email method : " + rs.getString(4));
				return student1;
			}
		});
		return student2;
	}

	@SuppressWarnings("static-access")
	@Override
	public JSONObject getStudent(String uname, String upass) {
		JSONObject jsonObject = new JSONObject();
		String sql = "SELECT * FROM STUDENTS WHERE NAME='" + uname + "' AND  PASSWORD ='" + upass + "'";
		System.out.println(sql);

		try {
			jsonObject = jsonObject.fromObject(jdbcTemplate.queryForMap(sql));
			jsonObject.put("isLogin", true);
		} catch (Exception ex) {
			ex.printStackTrace();
			jsonObject.put("isLogin", false);
		}
		return jsonObject;
	}

	@Override
	public JSONObject contactUsForm(String message) {
		JSONObject jsonObject = new JSONObject();
		String sql = "insert into contact_us values(?)";
		System.out.println(sql);

		try {
			jsonObject = JSONObject.fromObject(jdbcTemplate.update(sql, new Object[] { message }));
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return jsonObject;
	}

	/*
	 * @Override public void editStudent(Student student) {
	 * 
	 * String sql =
	 * "update students set name ='"+s.getName()+"', email= '"+s.getEmail()
	 * +"', country= '"+s.getCountry()+"' where id= '"+s.getId() +"'";
	 * System.out.println(sql); jdbcTemplate.update(sql);
	 * 
	 * 
	 * String sql = "update students set name=?,email=?,country=? where id=?";
	 * 
	 * jdbcTemplate.update(sql, new Object[] {"4", student.getName(),
	 * student.getEmail(), student.getCountry() });
	 * 
	 * }
	 */

	/*
	 * @Override public JSONObject editStudent(int id, String username, String
	 * email, String country) { JSONObject jsonObject = new JSONObject(); String sql
	 * = "update students set name= '" + username + "', email= " + email +
	 * ", country= '" + country + "' where id=" + id + "'"; System.out.println(sql);
	 * 
	 * JSONObject.fromObject(jdbcTemplate.update(sql, new Object[] { id, username,
	 * email, country })); return jsonObject; }
	 */

	/*
	 * @SuppressWarnings("unchecked")
	 * 
	 * @Override public Student getStudentsById(int id) { String sql =
	 * "select * from students where id=?"; Student student1 = (Student)
	 * jdbcTemplate.queryForObject(sql, new Object[] { id }, new RowMapper() {
	 * 
	 * @Override public Object mapRow(ResultSet rs, int rowNum) throws SQLException
	 * {
	 * 
	 * Student student2 = new Student(); student2.setId(rs.getInt(1));
	 * student2.setName(rs.getString(2)); student2.setEmail(rs.getString(3));
	 * student2.setCountry(rs.getString(4));
	 * 
	 * return student2; } }); return student1; }
	 * 
	 * @Override public List<Student> getAllStudents() { String sql =
	 * "select * from students;"; List<Student> studentList =
	 * jdbcTemplate.query(sql, new ResultSetExtractor<List<Student>>() {
	 * 
	 * @Override public List<Student> extractData(ResultSet rs) throws SQLException,
	 * DataAccessException {
	 * 
	 * List<Student> list = new ArrayList<Student>();
	 * 
	 * while (rs.next()) { Student student = new Student();
	 * student.setId(rs.getInt(1)); student.setName(rs.getString(2));
	 * student.setEmail(rs.getString(3)); student.setCountry(rs.getString(4));
	 * list.add(student); }
	 * 
	 * return list; } }); return studentList; }
	 */

	@Override
	public JSONObject deleteStudent(int id) {

		JSONObject jsonObject = new JSONObject();
		String sql = "delete from students where id=?";
		System.out.println(sql);

		try {
			jsonObject = JSONObject.fromObject(jdbcTemplate.update(sql, new Object[] { id }));
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return jsonObject;
	}

	@Override
	public JSONObject editStudent(int id, String name, String email, String country) {
		JSONObject jsonObject = new JSONObject();
		// Student student = new Student();
		String sql = "update students set name=?, email=?, country=? where id=?";
		System.out.println(sql);

		try {
			jsonObject = JSONObject.fromObject(jdbcTemplate.update(sql, new Object[] { name, email, country, id }));
			// student.getId(), student.getName(), student.getEmail(), student.getCountry()
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return jsonObject;
	}

	/*@Override
	public JSONObject getAllStudents() {
		
		String sql = "select id, name, email, country from students";
		System.out.println(sql);
		
		JSONObject jsonObject = new JSONObject();	
		
		
		
		jsonObject.put("id", 1);
		jsonObject.put("name", 2);
		jsonObject.put("email", 3);
		jsonObject.put("country", 4);
		
		return null;
	}*/

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<Student> getAllStudents() {
	
    	String sql = "select id, name, email, country from students";
		System.out.println(sql);
		
		return jdbcTemplate.query(sql, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			
				Student student = new Student();
				student.setId(rs.getInt(1));
				student.setName(rs.getString(2));
				student.setEmail(rs.getString(3));
				student.setCountry(rs.getString(4));
				
				return student;
			}
		});
			
	}
}
