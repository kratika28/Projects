// Code goes here
var ctx;

var floors = [{
  "floor": "floor1",
  "rooms": [{
    "coordinates": [
      [5, 5],
      [50, 5],
      [50, 60],
      [5, 60]
    ],
    "occupancy": 20,
    "id": 1,
    "name": "room1"
  }, {
    "coordinates": [
      [5, 65],
      [50, 65],
      [50, 150],
      [5, 150]
    ],
    "occupancy": 40,
    "id": 2,
    "name": "room2"
  }, {
    "coordinates": [
      [5, 155],
      [50, 155],
      [50, 240],
      [5, 240]
    ],
    "occupancy": 10,
    "id": 3,
    "name": "room3"
  }, {
    "coordinates": [
      [5, 245],
      [50, 245],
      [50, 330],
      [5, 330]
    ],
    "occupancy": 25,
    "id": 17,
    "name": "room17"
  }, {
    "coordinates": [
      [5, 335],
      [50, 335],
      [50, 420],
      [5, 420]
    ],
    "occupancy": 55,
    "id": 4,
    "name": "room4"
  }, {
    "coordinates": [
      [5, 425],
      [50, 425],
      [50, 510],
      [5, 510]
    ],
    "occupancy": 50,
    "id": 18,
    "name": "room18"
  }, {
    "coordinates": [
      [55, 30],
      [150, 30],
      [150, 245],
      [250, 245],
      [250, 490],
      [210, 490],
      [210, 510],
      [55, 510]
    ],
    "occupancy": 70,
    "id": 5,
    "name": "room5"
  }, {
    "coordinates": [
      [410, 5],
      [510, 5],
      [510, 170],
      [410, 170]
    ],
    "occupancy": 20,
    "id": 6,
    "name": "room6"
  }, {
    "coordinates": [
      [515, 5],
      [615, 5],
      [615, 100],
      [515, 100]
    ],
    "occupancy": 30,
    "id": 7,
    "name": "room7"
  }, {
    "coordinates": [
      [620, 5],
      [720, 5],
      [720, 100],
      [620, 100]
    ],
    "occupancy": 40,
    "id": 8,
    "name": "room8"
  }, {
    "coordinates": [
      [725, 5],
      [825, 5],
      [825, 100],
      [725, 100]
    ],
    "occupancy": 50,
    "id": 9,
    "name": "room9"
  }, {
    "coordinates": [
      [830, 5],
      [930, 5],
      [930, 100],
      [830, 100]
    ],
    "occupancy": 5,
    "id": 10,
    "name": "room10"
  }, {
    "coordinates": [
      [935, 5],
      [1100, 5],
      [1100, 100],
      [935, 100]
    ],
    "occupancy": 50,
    "id": 11,
    "name": "room11"
  }, {
    "coordinates": [
      [935, 110],
      [1100, 110],
      [1100, 350],
      [935, 350]
    ],
    "occupancy": 90,
    "id": 12,
    "name": "room12"
  }, {
    "coordinates": [
      [935, 355],
      [1100, 355],
      [1100, 450],
      [935, 450]
    ],
    "occupancy": 43,
    "id": 13,
    "name": "room13"
  }, {
    "coordinates": [
      [410, 225],
      [615, 225],
      [615, 450],
      [415, 450]
    ],
    "occupancy": 59,
    "id": 14,
    "name": "room14"
  }, {
    "coordinates": [
      [620, 225],
      [930, 225],
      [930, 450],
      [620, 450]
    ],
    "occupancy": 20,
    "id": 15,
    "name": "room15"
  }, {
    "coordinates": [
      [550, 120],
      [930, 120],
      [930, 210],
      [550, 210]
    ],
    "occupancy": 65,
    "id": 16,
    "name": "room16"
  }]
}, {
  "floor": "floor2",
  "rooms": [{
    "coordinates": [
      [5, 5],
      [500, 5],
      [500, 500],
      [50, 500]
    ],
    "occupancy": 70,
    "id": 1,
    "name": "room1"
  }, {
    "coordinates": [
      [600, 5],
      [900, 5],
      [900, 400],
      [600, 400]
    ],
    "occupancy": 40,
    "id": 2,
    "name": "room2"
  }]
}, {
  "floor": "floor3",
  "rooms": [{
    "coordinates": [
      [10, 100],
      [500, 100],
      [500, 510],
      [50, 510]
    ],
    "occupancy": 50,
    "id": 1,
    "name": "room1"
  }, {
    "coordinates": [
      [600, 5],
      [900, 5],
      [900, 500],
      [600, 500]
    ],
    "occupancy": 20,
    "id": 2,
    "name": "room2"
  }]
}]

function draw(roomNo) {
  var rooms = floors[roomNo].rooms;
  var canvas = document.getElementById("mycanvas")
  ctx = canvas.getContext('2d');
  for (var i = 0; i < rooms.length; i++) {
    drawRoom(rooms[i]);
  };

  canvas.addEventListener('click', function() {
    var rect = canvas.getBoundingClientRect(); // get element's abs. position
    var x = event.clientX - rect.left; // get mouse x and adjust for el.
    var y = event.clientY - rect.top; // get mouse y and adjust for el.

    //alert('Mouse position: ' + x + ',' + y);
    // need to write logic to find the corresponding room nased on room coordinates and mouse position
    var clickedRoom = null;
    var rooms = floors[selectedFloor].rooms;
    for (var k = 0; k < rooms.length; k++) {
      if (isPointInPolygon([x, y], rooms[k].coordinates))
        document.getElementById("clickedRoom").innerHTML = "Clicked on " + rooms[k].name + ", Occupancy: " + rooms[k].occupancy;
    }
  });
}

function drawRoom(room) {
  var poly = room.coordinates;

  var color;
  if (room.occupancy >= 60)
    color = '#A6CAF0';
  else if (room.occupancy >= 30)
    color = '#FFCC99';
  else
    color = '#CCFF99'
  ctx.fillStyle = color;

  ctx.beginPath();

  ctx.moveTo(poly[0][0], poly[0][1]);
  for (var i = 1; i < poly.length; i++) {
    ctx.lineTo(poly[i][0], poly[i][1])
  }
  // ctx.moveTo(poly[0], poly[1]);
  // for (var item = 2; item < poly.length - 1; item += 2) {
  //   ctx.lineTo(poly[item], poly[item + 1])
  // }

  ctx.closePath();
  ctx.fill();

}

function isPointInPolygon(point, polygon) {
  var minX = polygon[0][0];
  var maxX = polygon[0][0];
  var minY = polygon[0][1];
  var maxY = polygon[0][1];

  for (var i = 0; i < polygon.length; i++) {
    var q = polygon[i];
    minX = Math.min(q[0], minX);
    maxX = Math.max(q[0], maxX);
    minY = Math.min(q[1], minY);
    maxY = Math.max(q[1], maxY);
  }

  if (point[0] < minX || point[0] > maxX || point[1] < minY || point[1] > maxY) {

    return false;
  }

  var inside = false;
  for (var i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    if ((polygon[i][1] > point[1]) != (polygon[j][1] > point[1]) &&
      point[0] < (polygon[j][0] - polygon[i][0]) * (point[1] - polygon[i][1]) / (polygon[j][1] - polygon[i][1]) + polygon[i][0]) {
      inside = !inside;
    }
  }
  //console.log(inside);
  return inside;
}
var selectedFloor = 0;

function updateFloor() {
  selectedFloor = document.getElementById("floorSelect").value;
  document.getElementById("clickedRoom").innerHTML = "Selected Floor " + (parseInt(selectedFloor) + 1);
  console.log(ctx);
  ctx.clearRect(0, 0, 1200, 550);
  draw(selectedFloor);
}

  function renderError() {
    $("#chart").empty();
    $("#chartError").show();
}
 
function reloadGraph(RoomNum) {
    $.ajax({
        url: encodeURI("/jsp/index/" + RoomNum),
        type: "GET",
        dataType: "json",
        success: renderGraph,
        error: renderError
    });
}
 
function initializeFloors() {
    $("#floorSelect").change(function() {
        var RoomNum = $(this).val();
        reloadGraph(RoomNum);
    });
    reloadGraph($("#floorSelect").val());
}
 
$(document).ready(initializeFloors);
